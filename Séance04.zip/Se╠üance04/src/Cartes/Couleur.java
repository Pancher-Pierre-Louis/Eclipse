package Cartes;

enum Couleur {
    CARREAU, PIQUE, COEUR, TREFLE;
}