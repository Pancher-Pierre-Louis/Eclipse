package Cartes;


public enum Valeur {
    TROIS(3), QUATRE(4), CINQ(5),SIX(6), SEPT(7), HUIT(8), NEUF(9), DIX(10), VALET(11), DAME(12), ROI(13), AS(14);
    // Chaque constante est associée à un nombre entre parenthèses : sa puissance.

    private int puissance; // Champ pour stocker la valeur numérique (7, 8, 9, ...)

    private Valeur(int puissance) {
        // Constructeur appelé automatiquement pour chaque valeur de l’enum
        this.puissance = puissance;
    }

    public int getPuissance() {
        // Getter : permet de récupérer la puissance d’une carte
        return puissance;
    }
    
}