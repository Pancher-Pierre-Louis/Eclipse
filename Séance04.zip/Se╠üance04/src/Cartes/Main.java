package Cartes;


public class Main {

	public static void main(String[] args) {
		Carte32 uneCarte = new Carte32(Valeur.AS, Couleur.PIQUE);
		String m = uneCarte.getMotif();                 // "Classique"
		int v = uneCarte.getValeur().getPuissance();    // 14
		
        System.out.println(m); // Affiche "Classique"
        System.out.println(v); // Affiche "14"
        
        Paquet32 nouveauPaquet = new Paquet32();
        System.out.println(nouveauPaquet.getCarte(0));
	}
	
}	